## Screen Grabs of V 1.2.1 of C# Windows Installer.  
This will be used as reference for the development of the UI for a Delphi version of the Windows Installer.
