# Contributing to the Windows Installer  

* In case you find any bugs or have feature requests or improvements, please feel free to open an Issue in the Issue Tracker.
